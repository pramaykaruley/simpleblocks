#!/bin/bash

sudo apt-get install libx11-dev
sudo apt-get install libwxgtk3.0-0v5
sudo apt-get install libgamin0
#package installtion
sudo apt-get remove codeblocks
sudo rm -dR /usr/local/share/codeblocks
sudo dpkg -i simpleblocks_1.0-0_amd64.deb
sudo dpkg -i wxwidgets_3.0.3-1_amd64.deb
#granting permission
sudo chmod /etc/ld.so.conf
sudo chmod -R 777 /usr/local/share/codeblocks/simplecpp
grep -q -F '/usr/local/lib' /etc/ld.so.conf || echo '/usr/local/lib' >> /etc/ld.so.conf
sudo ldconfig
echo "Codeblocks Installed Successfully, Enjoy Coding..."
echo "Bye!!!"
exit 0;
